import cv2
import time
from ultralytics import YOLO

# ===== KONFIGURASI =====
# Muat model YOLOv8 object detection yang sudah dilatih
model = YOLO('best_nano.pt')

# Daftar karakter untuk mode pengetikan
CHARACTERS = 'abcdefghijklmnopqrstuvwxyz0123456789'

# Durasi dalam detik untuk memicu sebuah aksi
HOLD_DURATION_SECONDS = 1.0
# Interval pergantian karakter dalam detik
CHAR_CYCLE_INTERVAL = 0.8


# ===== INISIALISASI VARIABEL STATE =====
# Hubungkan ke webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Tidak bisa membuka kamera.")
    exit()

# Teks yang akan diketik oleh pengguna
typed_text = ""
# Variabel untuk melacak state deteksi
last_detection = "netral" # Mulai dengan state netral
detection_start_time = time.time()
# Flag untuk memastikan aksi (hapus/clear) hanya dieksekusi sekali per gestur
action_triggered = False

print("Program dimulai. Arahkan wajah ke kamera.")
print("Tekan 'q' untuk keluar.")

# ===== LOOP UTAMA PROGRAM =====
while True:
    success, frame = cap.read()
    if not success:
        print("Gagal menangkap frame.")
        break

    # Balik frame secara horizontal (efek cermin)
    frame = cv2.flip(frame, 1)
    
    # Lakukan inferensi object detection pada frame
    results = model(frame, verbose=False)
    
    # --- LOGIKA BARU UNTUK MEMBACA HASIL OBJECT DETECTION ---
    current_detection = "netral" # Default state jika tidak ada deteksi yang relevan
    confidence = 0.0

    # Cek apakah ada objek yang terdeteksi
    if len(results[0].boxes) > 0:
        # Ambil semua confidence score dan class index dari objek yang terdeteksi
        confidences = results[0].boxes.conf
        class_indices = results[0].boxes.cls

        # Cari index dari box dengan confidence score tertinggi
        best_box_index = confidences.argmax()

        # Dapatkan class index dan confidence score dari box terbaik tersebut
        top1_class_index = int(class_indices[best_box_index].item())
        confidence = confidences[best_box_index].item()
        
        # Dapatkan nama kelas (label) dari index
        current_detection = model.names[top1_class_index]
    # --------------------------------------------------------

    # Dapatkan waktu saat ini
    current_time = time.time()
    
    char_to_display = ""

    # --- LOGIKA KONTROL BERBASIS GESTUR (TETAP SAMA SEPERTI SEBELUMNYA) ---

    # 1. Cek jika ada perubahan gestur
    if current_detection != last_detection:
        # Jika gestur sebelumnya adalah 'left_open' dan ditahan cukup lama,
        # maka tambahkan karakter terakhir ke teks.
        if last_detection == 'left_open':
            hold_duration = current_time - detection_start_time
            if hold_duration >= HOLD_DURATION_SECONDS:
                selection_duration = hold_duration - HOLD_DURATION_SECONDS
                char_index = int(selection_duration / CHAR_CYCLE_INTERVAL) % len(CHARACTERS)
                typed_text += CHARACTERS[char_index]

        # Reset state untuk gestur baru
        last_detection = current_detection
        detection_start_time = current_time
        action_triggered = False

    # 2. Proses gestur yang sedang berlangsung (ditahan)
    else:
        duration_held = current_time - detection_start_time
        
        if duration_held >= HOLD_DURATION_SECONDS:
            if current_detection == 'left_open':
                # Masuk ke mode pemilihan karakter
                selection_duration = duration_held - HOLD_DURATION_SECONDS
                char_index = int(selection_duration / CHAR_CYCLE_INTERVAL) % len(CHARACTERS)
                char_to_display = CHARACTERS[char_index]
            
            elif current_detection == 'right_open' and not action_triggered:
                # Fungsi Hapus (Backspace)
                if len(typed_text) > 0:
                    typed_text = typed_text[:-1]
                action_triggered = True # Tandai aksi sudah dilakukan
            
            elif current_detection == 'closed_eye' and not action_triggered:
                # Fungsi Hapus Semua (Clear)
                typed_text = ""
                action_triggered = True # Tandai aksi sudah dilakukan

    # --- VISUALISASI PADA LAYAR ---
    
    # Gambar hasil deteksi dari YOLO (sekarang akan menggambar bounding box)
    annotated_frame = results[0].plot()

    # Siapkan area untuk menampilkan teks
    h, w, _ = annotated_frame.shape
    font = cv2.FONT_HERSHEY_SIMPLEX

    # Tampilkan teks yang diketik di bagian atas-tengah
    text_size, _ = cv2.getTextSize(typed_text, font, 1.2, 3)
    text_x = (w - text_size[0]) // 2
    # Buat latar belakang hitam agar teks mudah dibaca
    cv2.rectangle(annotated_frame, (text_x - 10, 20), (text_x + text_size[0] + 10, 60 + text_size[1]), (0, 0, 0), -1)
    cv2.putText(annotated_frame, typed_text, (text_x, 80), font, 1.2, (255, 255, 255), 3)

    # Tampilkan karakter yang sedang dipilih (jika dalam mode pemilihan)
    if char_to_display:
        char_size, _ = cv2.getTextSize(char_to_display, font, 4, 8)
        char_x = (w - char_size[0]) // 2
        char_y = (h + char_size[1]) // 2
        cv2.putText(annotated_frame, char_to_display, (char_x, char_y), font, 4, (0, 255, 0), 8, cv2.LINE_AA)

    # Tampilkan status deteksi saat ini untuk umpan balik pengguna
    status_text = f"Status: {current_detection} ({confidence:.2f})"
    cv2.putText(annotated_frame, status_text, (10, h - 10), font, 0.7, (0, 0, 255), 2)

    # Tampilkan jendela hasil
    cv2.imshow("Eye Controlled Typing", annotated_frame)

    # Cek jika tombol 'q' ditekan untuk keluar
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Lepaskan sumber daya setelah loop selesai
cap.release()
cv2.destroyAllWindows()