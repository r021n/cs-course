import React from "react";

function TodoItem({ todo }) {
  return <li className="todo-item">{todo.text}</li>;
}

export default TodoItem;
