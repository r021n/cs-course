import React, { useState } from "react";
import TodoForm from "./components/TodoForm";
import TodoList from "./components/TodoList";

function App() {
  const [todos, setTodos] = useState([
    { id: 1, text: "Ini todo pertama", isCompleted: true },
    { id: 2, text: "Ini todo kedua", isCompleted: false },
    { id: 3, text: "Ini todo ketiga", isCompleted: false },
  ]);

  return (
    <div className="app">
      <h1>My TodoList</h1>
      <TodoForm />
      <TodoList todos={todos} />
    </div>
  );
}

export default App;
